package com.example.myapplication;

import android.icu.lang.UScript;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class MainActivity extends AppCompatActivity {


    TextView workingTV;
    TextView resultTV;
    String workings;
    String formula="";
    String tempFormula="";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initTextviews();

    }

    private void initTextviews() {
        workingTV=(TextView)findViewById(R.id.workingTextView);
        resultTV=(TextView) findViewById(R.id.resultTextView);
    }

    private void setworkings(String givenvalue)
    {
        workings=workings+givenvalue;
        workingTV.setText(workings);
    }

    public void EqualOnClick(View view) throws ScriptException {
       Double result= null;
        ScriptEngine engine=new ScriptEngineManager().getEngineByName("rhino");
        checkForPowerof();


        try{
        result=(double)engine.eval(formula);}
        catch (ScriptException e)
        {

            Toast.makeText(this, "Invalid Input", Toast.LENGTH_SHORT).show();
        }
        if( result!=null) resultTV.setText(String.valueOf(result.doubleValue()));

    }

    private void checkForPowerof() {
        ArrayList<Integer>indexOfPowers=new ArrayList<>();
        for(int i=0;i<workings.length();i++){
                if (workings.charAt(i)=='^')
                    indexOfPowers.add(i);
        }
        formula=workings;
        tempFormula=workings;
        for(Integer index:indexOfPowers){

            changeFormula(index);
        }
        formula=tempFormula;
    }

    private void changeFormula(Integer index) {

        String numberLeft="";
        String numberRight="";
        for (int i=index+1;i<workings.length();i++) {

            if(isNumeric(workings.charAt(i)))
                numberRight=numberRight+workings.charAt(i);
            else break;
        }

        for (int i=index-1;   i>0;   i--) {

            if(isNumeric(workings.charAt(i)))
                numberLeft =  numberLeft + workings.charAt(i);
            else break;
        }
        String original=numberLeft + "^" + numberRight;
        String changed="match.pow("+numberLeft+","+numberRight+")";
        tempFormula=tempFormula.replace(original,changed);

    }

    private  boolean isNumeric(char c)
    {
        if(( c <='9' && c>='0') || c=='.')
       return true;

        return false;

    }
    public void ClearOnClick(View view) {
        workingTV.setText("");
        workings="";
        resultTV.setText("");
        leftBracket=true;
    }

    boolean leftBracket=true;


    public void BracketOnClick(View view) {

        if (leftBracket){
            setworkings("(");
        leftBracket=false;}
        else
            {

                setworkings(")");
                leftBracket=true;

            }
    }

    public void PowerOnClick(View view) {

        setworkings("^");
    }

    public void DivideOnClick(View view) {
        setworkings("/");
    }

    public void SevenOnClick(View view) {
        setworkings("7");
    }

    public void EightOnClick(View view) {
        setworkings("8");
    }

    public void NineOnClick(View view) {
        setworkings("9");
    }

    public void MultiplyOnClick(View view) {
        setworkings("*");
    }

    public void FourOnClick(View view) {
        setworkings("4");
    }

    public void FiveOnClick(View view) {
        setworkings("5");
    }

    public void SixOnClick(View view) {
        setworkings("6");
    }

    public void AddOnClick(View view) {
        setworkings("+");
    }

    public void OneOnClick(View view) {
        setworkings("1");
    }

    public void TwoOnClick(View view) {
        setworkings("2");
    }

    public void ThreeOnClick(View view) {
        setworkings("3");
    }

    public void SubOnClick(View view) {
        setworkings("-");
    }

    public void ZeroOnClick(View view) {
        setworkings("0");
    }

    public void DecimalOnClick(View view) {
        setworkings(".");
    }


}